setwd("C:\\Users\\IT24102779\\Desktop\\IT24102779")
#Import
branch.data <- read.table("Exercise.txt", header = TRUE)

#View first few rows
head(branch.data)



#Q2
str(branch.data)



#Q3
boxplot(branch_data$Sales_X1, main = "Boxplot of Sales")

#Q4
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#Q5
find_outliers(branch_data$Years_X3)
