setwd("C:\\Users\\damse\\Desktop\\IT24102779")
#Question 1
#1
n <- 50
p <- 0.85

#2
1 - pbinom(46, size=n, prob=p)

#Question 2
#1,2
lambda <- 12

#3
dpois(15, lambda)


